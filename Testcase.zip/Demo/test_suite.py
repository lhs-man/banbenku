# coding:utf-8
import unittest

class  kk(unittest.TestCase):
    def test_01(self):
        print("kk1")

    def test_02(self):
        print("kk2")

    def test_03(self):
        print("kk3")
if __name__ == '__main__':
    unittest.main()
