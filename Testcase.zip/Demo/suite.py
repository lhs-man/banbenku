# coding:utf-8
import unittest,os
from HTMLTestRunner import HTMLTestRunner

from Demo.test_suite import *

# 创建一个测试套件==list
suite=unittest.TestSuite()
# 添加测试用例(子元素)到套件(集合)
# 方法1
# suite.addTest(kk('test_02'))
# suite.addTest(kk('test_01'))
# suite.addTest(kk('test_03'))
# 方法2
# case=[kk('test_02'),kk('test_01'),kk('test_03')]
# suite.addTests(case)
# 方法3
# suite.addTests(unittest.TestLoader().loadTestsFromTestCase(kk))
# 方法4
# suite.addTests(unittest.TestLoader().loadTestsFromName("test_suite.kk"))

report_name='测试报告名称'
report_title='测试报告标题'
report_desc='测试报告描述'
report_path='./report/'
report_file=report_path+'report.html'
if not os.path.exists(report_path):
    os.mkdir(report_path)
else:
    pass
with open(report_file,'wb')as report:
    suite.addTests(unittest.TestLoader().loadTestsFromName("test_suite.kk"))
    # 套件通过TextTestRunner对象进行运行等同与unittest.main()
    #    runner=unittest.TextTestRunner()
    runner = HTMLTestRunner(stream=report,title=report_title,description=report_desc)
    runner.run(suite)

report.close()

