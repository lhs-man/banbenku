import yaml

file = open('b.yml',encoding='utf-8')
res =yaml.load(file,Loader=yaml.FullLoader)
#打印成字典模式
print(res)