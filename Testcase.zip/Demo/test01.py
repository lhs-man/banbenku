#coding:utf-8
#导入Unittest框架
import unittest
from time import sleep

from ddt import ddt, data, unpack
from selenium import webdriver

#@ddt实现数据驱动
@ddt
#定义一个继承TestCase类
class Demo (unittest.TestCase):
   #前置条件
    def setUp(self) -> None:
        self.driver=webdriver.Chrome()
    #后置条件
    def tearDown(self) -> None:
        sleep(2)
        self.driver.quit()

    #测试用例
    @data(('https://www.baidu.com/', '科比'),
      ('https://www.baidu.com/', '库里'),
      ('https://www.baidu.com/', '赵睿'))
    @unpack
    def test_1(self,url,text):
        self.driver.get(url)
        self.driver.find_element_by_id("kw").send_keys(text)
        self.driver.find_element_by_id("su").click()

    #UnitTest运行函数
    if __name__ == '__main__':
        unittest.main()

