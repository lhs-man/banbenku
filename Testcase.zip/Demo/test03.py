# coding:utf-8
# 导包
import unittest
import yaml
from ddt import ddt, data, unpack, file_data



# ddt数据驱动
@ddt
# 继承unittest.Testcase
class Demo(unittest.TestCase):
    # 准备数据
    @file_data('a.yml')
    # 测试用例
    # **kobe 即不知道会接受多少个数据，把数据以键值对的形势存储进字典
    def test_1(self, **kobe):
        name=kobe.get('name')
        self.assertNotEqual(name,'科比',msg="not")
        # print(kobe.get("name"))
        # print(kobe.get("text"))
        # print("66666666")
    # 主方法
if __name__ == '__main__':
    unittest.main()
