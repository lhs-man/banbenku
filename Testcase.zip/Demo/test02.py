# coding:utf-8
# 导包
import unittest
from time import sleep
from ddt import ddt, data, unpack
from selenium import webdriver


# ddt数据驱动

def readFile():
    datas = []
    file = open('data.txt', 'r', encoding='utf-8')
    for line in file.readlines():
        datas.append(line.strip('\n').split(','))
    return datas


@ddt
# 继承unittest.Testcase
class Demo(unittest.TestCase):

    # 初始化方法
    def setUp(self) -> None:
        self.driver=webdriver.Chrome()

    # 释放资源
    def tearDown(self) -> None:
        sleep(2)
        self.driver.quit()

    # 准备数据
    @data(*readFile())
    @unpack
    # 测试用例
    def test_1(self, url, txt):
        self.driver.get(url)
        self.driver.find_element_by_id("kw").send_keys(txt)
        self.driver.find_element_by_id("su")

    # 主方法
if __name__ == '__main__':
    unittest.main()
