# @Time : 2021.3.26 20:32 
# @Author : Bruce lee
# @File : test.py 
import pymysql

# 1.连接数据库
conn = pymysql.connect(host='127.0.0.1', port=3306, user='root', password='168168168', database='mytest')
# 2.操作数据库 cursor 游标 创建一个游标 执行sql语句获取结果数据
cur = conn.cursor()
# 增加
# sql = "insert into user(username,password) values('12346','123456')"
# 删除
# slq2 ="delete from user where username='123'"
# 修改
# sql3="update user set username='123' where username='12346'"
# cur.execute(sql3)
# cur.execute('commit')
# 查询   fetchall:查询所有,fetchon:查询1个，fenchmany(个数)：可以查询指定个数
sql4 = "select*from user"
result = cur.execute(sql4)
result = cur.fetchall()
result2 = cur.execute(sql4)
result2 = cur.fetchone()
result3 = cur.execute(sql4)
result3 = cur.fetchmany(2)
print(result, '\n', result2, '\n', result3)

# 关闭连接
conn.close()
