import pytest


# 前置与后置条件
def setup_function():
    print('setup')


def teardown_function():
    print('teardown')


# 测试用例
def test_02(kk):
    print('kk2')


def test_01(kk):
    print('kk1')


def test_03(oo):
    assert oo == 2, '失败'


# pytest运行主入口
if __name__ == '__main__':
    pytest.main(['test_case1.py'])
