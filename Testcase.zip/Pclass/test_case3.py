'''
    mark装饰器对所有用例进行标记，对不同标记进行区分管理
'''
import pytest

class CemaDemo:

    @pytest.mark.webui
    @pytest.mark.temp
    def test1(self):
        print('web1')


    @pytest.mark.webui
    @pytest.mark.temp
    def test2(self):
        print('web2')


    @pytest.mark.interface
    @pytest.mark.temp
    def test3(self):
        print('interface1')


    @pytest.mark.interface
    def vip4(self):
        print('interface2')


if __name__ == '__main__':
    pytest.main(['test_case3.py'])
