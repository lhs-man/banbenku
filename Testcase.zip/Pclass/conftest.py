import pytest




# 预置函数
# fixture的scope默认等级为function
@pytest.fixture(scope='session')
def kk():
    print('科比很强')


@pytest.fixture()
def oo():
    return 1
