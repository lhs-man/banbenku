import pytest



# 测试用例
def test2_02():
    print('case2_02')

@pytest.mark.webui
def test2_01():
    print('case2_01')

def test2_03(kk):
    print('case3_03')

# -s:输出打印信息；-v:用于详细显示日志信息;-rA:用于测试结果的简单记录
if __name__ == '__main__':
    pytest.main(['-s','test_case2.py::test2_03','-v','-rA'])