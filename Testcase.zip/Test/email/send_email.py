# @Time : 2021.3.28 8:22 
# @Author : Bruce lee
# @File : send_email.py
from email import encoders
from email.mime.text import MIMEText  # 处理邮件内容的库
import smtplib
# 处理邮件附件，需要导入MIMEMultipart， Header， MIMEBase
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.mime.base import MIMEBase

# qq授权码：ukoyhwcrybppbcjh
# 邮箱属性的配置
mailServer = 'smtp.qq.com'  # 邮箱服务器端URL
userName_SendMail = '908895266@qq.com'  # 发件人
userName_AuthCode = 'ukoyhwcrybppbcjh'  # 邮件发送授权码
received_mail = ['2737945602@qq.com']  # 定义邮件的接收者，如果要发送多个就用逗号隔开直接写
# 发送一个简单的邮件
# content = '这是一封简单文本内容的邮件'
# email = MIMEText(content, 'plain', 'utf-8')  # 纯文本形式的邮件内容的定义，通过MIMEText进行操作
# email['Subject'] = '邮件主题'  # 定义邮件主题
# email['From'] = userName_SendMail  # 发件人
# email['To'] = ','.join(received_mail)  # 收件人，以，作为分隔符

# 发送一封html内容的邮件
# content="""
# <p>这是一封HTML文本的邮件</p>
# <p><a href="https://www.baidu.com">点击这里跳转</a></p>
# """
# email =MIMEText(content,'html','utf-8')
# email['Subject']='邮件主题——HTML'
# email['From']=userName_SendMail
# email['To']=','.join(received_mail)

# 邮件中发送附件
# 1.非图片附件
#  附件配置邮箱
# email = MIMEMultipart()
# email['Subject'] = '邮件主题_添加非图片附件'
# email['From'] = userName_SendMail
# email['To'] = ','.join(received_mail)
#
# att = MIMEBase('application', 'octet-stream')
# att.set_payload(open('科比.txt', 'rb').read())
# att.add_header('Content-Disposition', 'attachment', filename=Header('科比.txt', 'gbk').encode())
# encoders.encode_base64(att)
# email.attach(att)

# 2.图片附件
# 附件配置邮箱
email = MIMEMultipart()
email['Subject'] = '邮件主题_图片附件'
email['From'] = userName_SendMail
email['To'] = ','.join(received_mail)

att1 = MIMEBase('application', 'octet-stream')
att1.set_payload(open('科比.jpg', 'rb').read())
att1.add_header('Content-Disposition', 'attachment', filename=Header('科比.jpg', 'gbk').encode())
encoders.encode_base64(att1)
email.attach(att1)

# 发送邮件
smtp = smtplib.SMTP_SSL(mailServer, port=465)      #非qq邮箱，一班使用SMTP即可，不需要SSL
smtp.login(userName_SendMail, userName_AuthCode)
smtp.sendmail(userName_SendMail, ','.join(received_mail), email.as_string())
smtp.quit()
print('ok')
