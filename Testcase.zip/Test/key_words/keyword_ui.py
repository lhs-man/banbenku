# @Time : 2021.3.26 12:44 
# @Author : Bruce lee
# @File : keyword_ui.py
from time import sleep

from selenium import webdriver


# 使用啥浏览器
def browser(type_):
    try:
        driver = getattr(webdriver, type_)()
        return driver
    except:
        return webdriver.Chrome()


# 定义关键字类
class KeyUI():
    #  构造函数：driver可能会是任何的一种浏览器
    def __init__(self, type_):
        self.driver = browser(type_)

    # 常用关键字定义
    # 访问url
    def open(self, url):
        self.driver.get(url)

    # 元素定位
    def locator(self, name, value):
        return self.driver.find_element(name, value)

    # 输入
    def input(self, name, value, txt):
        self.locator(name, value).send_keys(txt)

    # 点击
    def click(self, name, value):
        self.locator(name, value).click()
    #等待
    def wait(self,time_):
        sleep(time_)

    # 关闭
    def close(self):
        self.driver.quit()
