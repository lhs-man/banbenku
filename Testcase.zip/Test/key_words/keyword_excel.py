# @Time : 2021.3.26 15:50 
# @Author : Bruce lee
# @File : keyword_zhuce.py
from time import sleep

from selenium import webdriver


def browser(type_):
    try:
        driver = getattr(webdriver, type_)()
        return driver
    except:
        return webdriver.Chrome()


class Login():
    def __init__(self, type_):
        self.driver = browser(type_)

    # 访问url
    def open(self, **kwargs):
        self.driver.get(kwargs['txt'])

    # 定位元素
    def locator(self, **kwargs):
        return self.driver.find_element(kwargs['name'], kwargs['value'])

    # 输入
    def input(self, **kwargs):
        self.locator(**kwargs).send_keys(kwargs['txt'])
    #点击
    def click(self,**kwargs):
        self.locator(**kwargs).click()
    #等待
    def wait(self,**kwargs):
        sleep(kwargs['txt'])
    #关闭
    def close(self,**kwargs):
        self.driver.quit()