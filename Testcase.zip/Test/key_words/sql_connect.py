# @Time : 2021.3.26 23:43 
# @Author : Bruce lee
# @File : sql_connect.py 
import pymysql
import configparser
class Connect():
    # 初始化方法，只要一调用就会执行
    def __init__(self,config_file,db):
        config=configparser.ConfigParser()
        #从配置文件里读取数据库服务器Ip,账号，密码....
        config.read(config_file)
        host=config[db]['host']
        port = int(config[db]['port'])
        user = config[db]['user']
        password=config[db]['password']
        database=config[db]['database']

        try:
            self.conn = pymysql.connect(
                host=host,
                port=port,
                user=user,
                password=password,
                database=database
            )
        except Exception as e:
            print('连接失败',e)
    def select_all(self,query):
        try:
            cur = self.conn.cursor()
            # 编写slq语句
            cur.execute(query)
            result = cur.fetchmany(2)
            self.conn.close()
            return result
        except Exception as e:
            print('查询失败',e)

