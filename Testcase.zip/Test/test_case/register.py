# @Time : 2021.3.26 16:01 
# @Author : Bruce lee
# @File : register.py
from ddt import ddt, file_data
from key_words.keyword_ui import KeyUI
from key_words.keyword_zhuce import Register
import unittest


@ddt
class Register_case(unittest.TestCase):

    # 编写注册用例
    @file_data('..//data//register.yaml')
    def test1(self, **kwargs):
        rg = Register(kwargs['type'])
        rg.open(kwargs['url'])
        rg.click(**kwargs['click'])
        rg.wait(1)
        rg.input(**kwargs['email'])
        rg.input(**kwargs['nickname'])
        rg.input(**kwargs['pwd'])
        rg.input(**kwargs['pwd2'])
        rg.click(**kwargs['click2'])
        rg.wait(2)
        rg.close()

    @file_data('..//data//login.yaml')
    def test2(self, **kwargs):
        lg = Register(kwargs['type'])
        lg.open(kwargs['url'])
        lg.click(**kwargs['click'])
        lg.wait(1)
        lg.input(**kwargs['email'])
        lg.input(**kwargs['pwd'])
        lg.click(**kwargs['click2'])
        lg.wait(2)
        lg.close()

if __name__ == '__main__':
    unittest.main()
