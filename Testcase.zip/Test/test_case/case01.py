# @Time : 2021.3.26 13:06 
# @Author : Bruce lee
# @File : case01.py
from ddt import ddt, file_data

from key_words.keyword_ui import KeyUI
import unittest


@ddt
class Demo(unittest.TestCase):


        @file_data('..//data//a.yaml')
        def test1(self, **kwargs):
            ku = KeyUI(kwargs['type'])
            ku.open(kwargs['url'])
            ku.click(kwargs['click']['name1'], kwargs['click']['value'])
            ku.wait(kwargs['time'])
            ku.input(kwargs['input']['name1'], kwargs['input']['value'], kwargs['input']['txt'])
            ku.input(kwargs['input']['name1'], kwargs['input']['value2'], kwargs['input']['txt2'])
            ku.click(kwargs['click']['name2'], kwargs['click']['value2'])
            ku.wait(kwargs['time'])
            ku.click(kwargs['click']['name3'], kwargs['click']['value3'])
            ku.wait(kwargs['time'])
            ku.click(kwargs['click']['name4'], kwargs['click']['value4'])
            ku.wait(kwargs['time'])
            ku.close()


if __name__ == '__main__':
    unittest.main()
