# @Time : 2021.3.26 17:14 
# @Author : Bruce lee
# @File : test_suite.py
import unittest,os

from HTMLTestRunner import HTMLTestRunner

# 创建一个测试套件==list
from test_case.register import Register_case

suite=unittest.TestSuite()
# suite.addTests(unittest.TestLoader().loadTestsFromName("register.Register_case"))
# runner=unittest.TextTestRunner()
# runner.run(suite)

report_name='测试报告名称'
report_title='测试报告标题'
report_desc='测试报告描述'
report_path='./report/'
report_file=report_path+'report.html'
if not os.path.exists(report_path):
    os.mkdir(report_path)
else:
    pass
with open(report_file,'wb')as report:
    suite.addTests(unittest.TestLoader().loadTestsFromName("register.Register_case"))
    # 套件通过TextTestRunner对象进行运行等同与unittest.main()
    #    runner=unittest.TextTestRunner()
    runner = HTMLTestRunner(stream=report,title=report_title,description=report_desc)
    runner.run(suite)

report.close()

