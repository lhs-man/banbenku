# @Time : 2021.3.26 8:46 
# @Author : Bruce lee
# @File : test1.py
from time import sleep
import unittest
from ddt import ddt, unpack, data
from selenium import webdriver
from key_words.sql_connect import Connect
#实例化
sql_data=Connect('./config/dbconfig.conf','MYDB')   #第一个参数传入数据库配置连接的文件位置，第二个参数则是选择使用哪个连接
result=sql_data.select_all('select*from user')

@ddt
class Demo(unittest.TestCase):

    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.get('http://www.testclass.net/')

    def tearDown(self) -> None:
        sleep(3)
        self.driver.quit()

    # 自己的数据
    # @data(['12345@qq.com', '1qaz2wsx'], ['56575@qq.com', '123456'], ['6767@qq.com', '123456'])
    # 引用mysql数据库里的数据
    @data(*result)
    @unpack  # 解包
    def test1(self, username, password):
        self.driver.find_element_by_link_text('用户登录').click()
        sleep(1)
        self.driver.find_element_by_xpath('//*[@id="reader_email"]').send_keys(username)
        self.driver.find_element_by_xpath('//*[@id="reader_password"]').send_keys(password)
        self.driver.find_element_by_name('commit').click()
        sleep(2)
        self.driver.find_element_by_partial_link_text('lee').click()
        sleep(1)
        self.driver.find_element_by_link_text('登出').click()


if __name__ == '__main__':
    unittest.main()
