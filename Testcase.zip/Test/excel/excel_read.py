# @Time : 2021.3.28 12:26 
# @Author : Bruce lee
# @File : excel_read.py 
import openpyxl
#1 打开excel
from key_words.keyword_excel import Login

excel=openpyxl.load_workbook('./test_cases/test_demo.xlsx')
# 2 指定需要的sheet页
# sheet=excel['sheet1']
sheets=excel.sheetnames
for sheet1 in sheets:
    sheet=excel[sheet1]
    for values in sheet.values:
        params={}
        params['name']=values[2]
        params['value']=values[3]
        params['txt']=values[4]
        if type(values[0]) is int:
            print(values)
            if values[1]=='browser':
                web=Login(params['txt'])
            else:
                getattr(web,values[1])(**params)
        else:
            print(values[0])





