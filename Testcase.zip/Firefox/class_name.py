from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
driver.get("https://www.baidu.com/")
driver.find_element_by_class_name("s_ipt").send_keys("赵睿")
sleep(2)
driver.quit()