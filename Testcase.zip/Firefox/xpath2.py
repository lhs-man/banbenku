from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
url="file:///D:/Users/ASUS/PycharmProjects/Testcase/Firefox/test2.html"
driver.get(url)
# 使用xpath相对路径定位元素
driver.find_element_by_xpath("//input[@name='u']").send_keys("科比")
driver.find_element_by_xpath("//input[@name='p']").send_keys("123456")
sleep(2)
driver.quit()