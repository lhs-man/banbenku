from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
driver.get("file:///D:/Users/ASUS/PycharmProjects/Testcase/Firefox/test.html")
# elements 使用下标进行定位
driver.find_elements_by_tag_name("input")[1].send_keys("kebi")
sleep(3)
driver.quit()