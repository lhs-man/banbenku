from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
driver.get("https://www.baidu.com/")
driver.find_element_by_name("wd").send_keys("库里")
sleep(2)
driver.quit()