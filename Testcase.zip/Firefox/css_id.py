from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
url="https://www.baidu.com"
driver.get(url)

driver.find_element_by_css_selector("#kw").send_keys("kebni")
sleep(2)
driver.quit()