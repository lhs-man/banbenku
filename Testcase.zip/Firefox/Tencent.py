from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
url="https://www.baidu.com/"
driver.get(url)
driver.find_element_by_id("kw").send_keys("科比")
driver.find_element_by_id("su").click()
sleep(2)
driver.find_element_by_xpath("//*[@id='1']/h3/a").click()
sleep(5)
driver.quit()