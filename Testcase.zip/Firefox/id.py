from selenium import webdriver
from time import sleep

driver = webdriver.Firefox()
driver.get("https://www.baidu.com/")
kk = driver.find_element_by_id("kw").send_keys("科比")
# kk.send_keys("科比")
sleep(3)
driver.quit()
