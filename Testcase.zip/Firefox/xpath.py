from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
url="file:///D:/Users/ASUS/PycharmProjects/Testcase/Firefox/test2.html"
driver.get(url)
# 使用xpath绝对路径定位元素
driver.find_element_by_xpath("/html/body/div/form/input[1]").send_keys("kebi")
driver.find_element_by_xpath("/html/body/div/form/input[2]").send_keys("123456")
sleep(2)
driver.quit()