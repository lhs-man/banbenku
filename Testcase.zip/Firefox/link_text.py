from time import sleep

from selenium import webdriver
driver=webdriver.Firefox()
driver.get("https://www.baidu.com/")
# driver.find_element_by_link_text("新闻").click() 超链接全部匹配
# partial_link_text局部匹配
driver.find_element_by_partial_link_text("新").click()
sleep(3)
driver.quit()