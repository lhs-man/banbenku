# @Time : 2021.3.23 19:49 
# @Author : Bruce lee
# @File : test.py
import time
import yaml
from appium import webdriver


def Start():
    stream = open('data.yml', 'r')
    data = yaml.load(stream, Loader=yaml.FullLoader)
    info = {}
    info['deviceName'] = data['deviceName']
    info['platformName'] = data['platformName']
    info['platformVersion'] = data['platformVersion']
    info['appPackage'] = data['appPackage']
    info['appActivity'] = data['appActivity']
    info['noReset'] = data['noReset']

    #
    driver = webdriver.Remote('http://' + str(data['ip']) + ':' + str(data['port']) + '/wd/hub', info)
    time.sleep(2)
    driver.quit()
    return driver


if __name__ == '__main__':
    Start()
