# @Time : 2021.3.23 17:33 
# @Author : Bruce lee
# @File : test1.py
import time

from appium import webdriver

info = {
    # 设备名  cmd-->adb devices
    "deviceName": "127.0.0.1:62001",
    # 测试的平台 androd ios 不分大小写
    "platformName": "Android",
    # 测试机的版本号，设置-->关于手机-->android版本
    "platformVersion": "7.1.2",
    # 第一种方法：测试程序的包名 cmd-->adb shell-->pm list package -3
    # 第二种： cmd->adb shell dumpsys window|findstr mCurrentFocu  获取模拟器当前页面的包名
    "appPackage": "com.tencent.mobileqq",
    # 界面名，即主程序，一样  adb shell dumpsys window|findstr mCurrentFocu
    "appActivity": "com.tencent.mobileqq.activity.SplashActivity",
    # 不重置，默认为false
    "noReset": True
}
# 启动程序
driver=webdriver.Remote('http://127.0.0.1:4723/wd/hub', info)
driver.find_element_by_id('com.tencent.mobileqq:id/icon').click()
driver.find_element_by_id('com.tencent.mobileqq:id/input').send_keys('帅哥你好')
driver.find_element_by_id('com.tencent.mobileqq:id/fun_btn').click()
time.sleep(3)
driver.quit()
